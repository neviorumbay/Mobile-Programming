import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

part 'bg.dart';
part 'color.dart';
part 'btn.dart';
part 'dialog.dart';
