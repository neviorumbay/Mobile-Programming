part of 'importutils.dart';

Color warnaUtama = Color(0xff281163);
Color hitam = Color(0xff2b2b2b);
Color putih = Colors.white;
